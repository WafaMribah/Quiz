package web.afor.innovation.quizzhub.Fragments;

import android.os.AsyncTask;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import web.afor.innovation.quizzhub.Activities.preferences;
import web.afor.innovation.quizzhub.Config.Constant;
import web.afor.innovation.quizzhub.Models.Answer;
import web.afor.innovation.quizzhub.R;

public class QuizFragment extends Fragment {

    private TextView textviewQuestion;
    private TextView rep1;
    private TextView rep2;
    private TextView rep3;
    private TextView rep4;
    private int score;
    private TextView textviewScore;

    private ArrayList<Answer> answer;

    private RelativeLayout transparentLayout;
    private TextView username;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_quiz, container, false);

        preferences.savePreferencesBoolean(getContext(), "firstrun", false);

        DownloadQuestion question = new DownloadQuestion();
        question.execute(Constant.BASE_URL + Constant.RANDOM_URL);

        answer = new ArrayList<Answer>();

        initViews(view);

        // Inflate the layout for this fragment
        return view;
    }

    private void initViews(View view) {
        textviewQuestion = (TextView) view.findViewById(R.id.textviewQuestion);
        rep1 = (TextView) view.findViewById(R.id.textviewResponse1);
        verifyAnswer(rep1,0);
        rep2 = (TextView) view.findViewById(R.id.textviewResponse2);
        verifyAnswer(rep2,1);
        rep3 = (TextView) view.findViewById(R.id.textviewResponse3);
        verifyAnswer(rep2,2);
        rep4 = (TextView) view.findViewById(R.id.textviewResponse4);
        verifyAnswer(rep2,3);
        textviewScore = (TextView) view.findViewById(R.id.scoreText);

        transparentLayout = (RelativeLayout) view.findViewById(R.id.transparentLayout);
        username = (TextView) view.findViewById(R.id.textviewUsername);


        /* SharedPreferences.Editor editor = sharedpreferences.edit();
        score=sharedpreferences.getInt("score",0);*/






    }
    private void verifyAnswer(final TextView textView , final int i) {
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answer.size() > i) {
                    if(!answer.get(i).isClicked()) {
                        if (answer.get(i).isValidAnswer()) {
                        incrementScore();
                            //Preferences.saveInt("key",score,getContext());
                            textView.setBackgroundDrawable(getResources().getDrawable(R.drawable.rdgreen));
                            newQuestion(getView());
                        } else {
                            decrementScore();
                            // Preferences.saveInt("key",score,getContext());
                            textView.setBackgroundDrawable(getResources().getDrawable(R.drawable.red));
                        }
                        textviewScore.setText(String.valueOf(score));
                        answer.get(i).setClicked(true);
                    }
                }
            }
        });
    }

    private void newQuestion (View view) {
        view.findViewById(R.id.progressBar).setVisibility(View.VISIBLE);
        android.os.Handler handler = new android.os.Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                new DownloadQuestion().execute(Constant.BASE_URL+Constant.URL_TAGS);

              rep4.setBackgroundDrawable(getResources().getDrawable(R.drawable.rd));
                rep1.setBackgroundDrawable(getResources().getDrawable(R.drawable.rd));
                rep2.setBackgroundDrawable(getResources().getDrawable(R.drawable.rd));
               rep3.setBackgroundDrawable(getResources().getDrawable(R.drawable.rd));
                rep1.setText("");
               rep2.setText("");
               rep3.setText("");
                rep4.setText("");
                textviewQuestion.setText("");


            }
        },1500);
    }
    private class DownloadQuestion extends AsyncTask<String, Void, String> {

        OkHttpClient client = new OkHttpClient();

        @Override
        protected String doInBackground(String... params) {

            Request.Builder builder = new Request.Builder();
            builder.url(params[0]);
            Request request = builder.build();
            try {
                Response response = client.newCall(request).execute();
                return response.body().string();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return null;
        }

        protected void onPostExecute(String s) {
            transparentLayout.setVisibility(View.INVISIBLE);

            try {
                JSONObject respo = new JSONObject(s);
                String question = respo.getString("question");
                JSONArray jArray = respo.getJSONArray("answers");

                for (int i = 0; i < jArray.length(); i++) {
                    try {
                        JSONObject oneObject = jArray.getJSONObject(i);
                        // Pulling items from the array
                        String rep=oneObject.getString("answer_text");
                        boolean b= oneObject.getBoolean("correct");

                        Log.d("ced","d"+rep);
                        Answer a=new Answer(rep,b,false);
                        answer.add(a);
                        // Pair<String, Boolean> p = new Pair<>(, oneObject.getBoolean("correct"));
                        // listAnswers.add(p);
                    } catch (JSONException e) {
                        // Oops
                    }
                }
                textviewQuestion.setText(question);
                if(answer.size()>0)
                    rep1.setText(answer.get(0).getResponse());
                if(answer.size()>1)
                    rep2.setText(answer.get(1).getResponse());
                if(answer.size()>2)
                    rep3.setText(answer.get(2).getResponse());
                if(answer.size()>3)
                    rep4.setText(answer.get(3).getResponse());

            } catch (JSONException e) {
                e.printStackTrace();
            }

            super.onPostExecute(s);
        }

    }

    public void incrementScore(){
        score+= Constant.incr;
        textviewScore.setText(String.valueOf(score));
    }
    public void decrementScore(){
        score-=Constant.decr;
        textviewScore.setText(String.valueOf(score));
    }

}



