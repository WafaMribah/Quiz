package web.afor.innovation.quizzhub.Config;

/**
 * Created by wafa on 8/3/16.
 */

    public final class BuildConfig {
        public final static boolean DEBUG = true;
    }

