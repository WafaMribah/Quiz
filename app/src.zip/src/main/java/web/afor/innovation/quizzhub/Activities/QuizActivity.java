package web.afor.innovation.quizzhub.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import web.afor.innovation.quizzhub.Config.Constant;
import web.afor.innovation.quizzhub.Models.Answer;
import web.afor.innovation.quizzhub.R;

public class QuizActivity extends AppCompatActivity {

    private TextView textQuestion;
    private TextView textAnswer1;
    private TextView textAnswer2;
    private TextView textAnswer3;
    private TextView textAnswer4;
    private TextView username ;

    private ArrayList<Answer> answer;
    int score;
    private TextView score_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_quiz);
        initviews();


        new DownloadQuestion().execute("http://web4innovation.bianucci.org/api/question/random");
        SharedPreferences sharedpref=getSharedPreferences("QuizApp",MODE_PRIVATE);
        score =sharedpref.getInt("score",0);
        score_view.setText(String.valueOf(score));
        Intent intent=getIntent();
        String usr =intent.getStringExtra("username");
        username.setText(usr);
    }

    protected  void save(){
        Context context= QuizActivity.this;
        SharedPreferences sharedpref =context.getSharedPreferences("QuizApp",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpref.edit();
        Log.d("sc",score+"");
        editor.putInt("score",score);
        editor.commit();


    }
    private void initviews() {

        textQuestion = (TextView) findViewById(R.id.TextQuestion);
        textAnswer1 =(TextView) findViewById(R.id.TextAnswer1);
        textAnswer2 =(TextView) findViewById(R.id.TextAnswer2);
        textAnswer3 =(TextView) findViewById(R.id.TextAnswer3);
        textAnswer4 =(TextView) findViewById(R.id.TextAnswer4);
        username= (TextView) findViewById(R.id.username_view);
        score_view=(TextView) findViewById(R.id.score);





        textAnswer1.setOnClickListener(new View.OnClickListener() {




            @Override
            public void onClick(View v) {

                if (answer.get(0).isValidAnswer()) {
                 Log.d("TAG","your response is true");
                    incrementScore();

                    textAnswer1.setBackgroundDrawable(getResources().getDrawable(R.drawable.rdgreen));


                    newQuestion();


                } else {
                    Log.d("TAG","your response is false");
                    textAnswer1.setBackgroundDrawable(getResources().getDrawable(R.drawable.red));
                    decrementScore();



                }
                save();

            }



        });
        textAnswer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answer.get(1).isValidAnswer()) {
                    Log.d("TAG","your response is true");

                    textAnswer2.setBackgroundDrawable(getResources().getDrawable(R.drawable.rdgreen));
                    incrementScore();

                 newQuestion();


                } else {
                    Log.d("TAG","your response is false");
                    textAnswer2.setBackgroundDrawable(getResources().getDrawable(R.drawable.red));
                    decrementScore();
                }
                save();

            }



        });
        textAnswer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answer.get(2).isValidAnswer()) {
                    Log.d("TAG","your response is true");
                    textAnswer3.setBackgroundDrawable(getResources().getDrawable(R.drawable.rdgreen));

                    newQuestion();
                    incrementScore();

                } else {
                    Log.d("TAG","your response is false");
                    textAnswer3.setBackgroundDrawable(getResources().getDrawable(R.drawable.red));
                    decrementScore();
                }
                save();

            }



        });
        textAnswer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answer.get(3).isValidAnswer()) {
                    Log.d("TAG","your response is true");
                    textAnswer4.setBackgroundDrawable(getResources().getDrawable(R.drawable.rdgreen));

                    incrementScore();
                    newQuestion();
                } else {
                    Log.d("TAG","your response is false");
                    textAnswer4.setBackgroundDrawable(getResources().getDrawable(R.drawable.red));
                    decrementScore();
                }
                save();

            }



        });
    }
    private void setData(String question ,ArrayList<Answer> listanswer){
       textQuestion.setText(question);
       textAnswer1.setText(listanswer.get(0).getResponse());
        textAnswer2.setText(listanswer.get(1).getResponse());
        textAnswer3.setText(listanswer.get(2).getResponse());
        textAnswer4.setText(listanswer.get(3).getResponse());
    }
    private void newQuestion () {
        findViewById(R.id.progress).setVisibility(View.VISIBLE);
        android.os.Handler handler = new android.os.Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                QuizActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        new DownloadQuestion().execute("http://web4innovation.bianucci.org/api/question/random");

                        textAnswer1.setBackgroundDrawable(getResources().getDrawable(R.drawable.rd));
                        textAnswer2.setBackgroundDrawable(getResources().getDrawable(R.drawable.rd));
                        textAnswer3.setBackgroundDrawable(getResources().getDrawable(R.drawable.rd));
                        textAnswer4.setBackgroundDrawable(getResources().getDrawable(R.drawable.rd));
                        textAnswer1.setText("");
                        textAnswer2.setText("");
                        textAnswer3.setText("");
                        textAnswer4.setText("");
                        textQuestion.setText("");




                    }

                });
            }
        },1500);




    }

    private class DownloadQuestion extends AsyncTask<String, Void, String> {
        OkHttpClient client = new OkHttpClient();


        protected String doInBackground(String... params) {

            Request.Builder builder = new Request.Builder();
            builder.url(params[0]);
            Request request = builder.build();
            try {
                Response response = client.newCall(request).execute();
                return response.body().string();

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }


        @Override
        protected void onPostExecute(String s) {

            //Log.d("st",s);
            final JSONArray objArray;
            answer=new ArrayList<Answer>();
            try {
                JSONObject jsonObject= new JSONObject(s);
                String question= jsonObject.getString("question");
                boolean choice=  jsonObject.getBoolean("multiple_choice");
                objArray=jsonObject.getJSONArray("answers");
                int answers_length= objArray.length();
                for(int i=0;i<answers_length;i++) {

                    JSONObject object = objArray.getJSONObject(i);
                    String answer_text=object.getString("answer_text");
                    Boolean valid=object.getBoolean("correct");

                    answer.add(new Answer(answer_text,valid,false));
                    Log.d("Tag","response "+answer_text+" ");

                }

                textQuestion.setText(question);
                if(answers_length>0)
                    textAnswer1.setText(answer.get(0).getResponse());
                if(answers_length>1)
                    textAnswer2.setText(answer.get(1).getResponse());
                if(answers_length>2)
                    textAnswer4.setText(answer.get(2).getResponse());
                if(answers_length>3)
                    textAnswer3.setText(answer.get(3).getResponse());




            } catch (JSONException e) {
                e.printStackTrace();
            }

            findViewById(R.id.progress).setVisibility(View.INVISIBLE);
            Log.d("Tag","response "+s);
            super.onPostExecute(s);
        }
    }


    public void incrementScore(){
        score+= Constant.incr;
        score_view.setText(String.valueOf(score));
    }
    public void decrementScore(){
        score-=Constant.decr;
        score_view.setText(String.valueOf(score));
    }
    @Override
    protected void onDestroy() {

        super.onDestroy();
    }
}



